insert into book values (101,'priya');
insert into book values (102,'riya');
insert into book values (103,'sri');
insert into book values (104,'ram');
insert into book values (105,'sam');