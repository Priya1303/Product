package com.webapp.demo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProductApplicationTests {

	@Test
	public void contextLoads() {
	}

}

/*
package application;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;

import com.seller.Main;
import com.seller.dao.Products;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Main.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SellerTest {
	
	@Autowired
    private TestRestTemplate restTemplate;

    @LocalServerPort
    private int port = 8080;

    private String getRootUrl() {
        return "http://localhost:" + port;
    }

    @Test
    public void contextLoads() {

    	
    }
	
    

    
    @Test
    public void testadd() {
		Products products = new Products();
	//	products.setId(1);
		products.setName("Pepsi");
		products.setDescription("Drink");
        ResponseEntity<Products> postResponse = restTemplate.postForEntity(getRootUrl() + "/addproduct", products, Products.class);
   //     assertNotNull(postResponse);
       assertNotNull(postResponse.getBody());
    }
	
    
    
	@Test
	public void testshow() 
	{
	HttpHeaders headers = new HttpHeaders();
	
	HttpEntity<String> entity = new HttpEntity<String>(null, headers);
	
	ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/showall",HttpMethod.GET, entity, String.class); 
	// assertNotNull(response.getBody());
			assertNotNull(response.getBody());
	
}
	
	
	@Test
    public void testshowone() {
		
		Products products = restTemplate.getForObject(getRootUrl() + "/show/1", Products.class);
      //  Employee employee = restTemplate.getForObject(getRootUrl() + "/employees/1", Employee.class);
        System.out.println(products.getId());
        assertNotNull(products);
    }
	
	
	@Test
    public void testUpdateshow() {
        int id = 1;
        Products products = restTemplate.getForObject(getRootUrl() + "/updateproduct/" + id, Products.class);
        products.setName("rabbit");
        products.setDescription("animal");
        restTemplate.put(getRootUrl() + "/products/" + id, products);
        Products updatedProducts = restTemplate.getForObject(getRootUrl() + "/updateproduct/" + id, Products.class);
        assertNotNull(updatedProducts);
    }

	
	@Test
    public void testDelete() {
         int id = 1;
         Products products = restTemplate.getForObject(getRootUrl() + "/delete/" + id, Products.class);
         assertNotNull(products);
         restTemplate.delete(getRootUrl() + "/products/" + id);
         try {
        	 products = restTemplate.getForObject(getRootUrl() + "/delete/" + id, Products.class);
         } catch (final HttpClientErrorException e) {
              assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
         }
    }
	
}

*/